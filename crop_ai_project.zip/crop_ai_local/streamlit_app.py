"""
=============================================================================
  CROP PREDICTION DASHBOARD  —  Streamlit UI
  Run with:  streamlit run streamlit_app.py
=============================================================================
"""

import os
import sys
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import streamlit as st
import joblib
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")
import plotly.graph_objects as go
import plotly.express as px

# Import helper functions from the pipeline module
sys.path.insert(0, os.path.dirname(__file__))
from crop_prediction import (
    generate_synthetic_dataset,
    predict_crops,
    get_ai_recommendation,
    display_ai_recommendation,
    FEATURE_COLS, ML_FEATURES, SEASONS, REGIONS,
    SOIL_MAP, CONFIG,
)

# ─── Page config ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="🌾 CropAI — Smart Crop Recommender",
    page_icon="🌾",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
  [data-testid="stSidebar"] { background: #1a2e1a; }
  [data-testid="stSidebar"] * { color: #e8f5e9 !important; }
  .stButton>button { background:#2e7d32; color:white; border-radius:8px; border:none; }
  .stButton>button:hover { background:#43a047; }
  .metric-card { background:#f1f8e9; border-radius:12px; padding:16px 20px;
                 border-left:4px solid #43a047; margin-bottom:8px; }
  .crop-badge { display:inline-block; background:#e8f5e9; color:#1b5e20;
                border-radius:20px; padding:4px 14px; font-weight:600;
                margin:4px; font-size:0.9em; border:1px solid #a5d6a7; }
  .ai-box { background:#fffde7; border-radius:12px; padding:20px;
            border-left:5px solid #f9a825; white-space:pre-wrap;
            font-family: 'Courier New', monospace; font-size:0.85em;
            line-height:1.6; max-height:600px; overflow-y:auto; }
  h1 { color:#1b5e20; }
  .stTabs [data-baseweb="tab"] { font-size:15px; font-weight:600; }
</style>
""", unsafe_allow_html=True)

# ─── Load or train model ──────────────────────────────────────────────────────
@st.cache_resource(show_spinner="Training models on synthetic data …")
def load_model():
    """Load saved model or train a fresh one."""
    model_path = CONFIG["model_save_path"]
    if os.path.exists(model_path):
        bundle = joblib.load(model_path)
        return bundle["pipeline"], bundle["label_encoder"]
    # Train fresh
    df = generate_synthetic_dataset(CONFIG["n_samples"])
    from crop_prediction import train_and_evaluate
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        pipeline, le, _ = train_and_evaluate(df)
    return pipeline, le


@st.cache_data(show_spinner="Generating dataset …")
def get_dataset():
    return generate_synthetic_dataset(CONFIG["n_samples"])


# ─── Sidebar — Inputs ────────────────────────────────────────────────────────
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/wheat.png", width=70)
    st.title("🌾 CropAI")
    st.caption("Smart Agricultural Recommendation System")
    st.markdown("---")
    st.subheader("🧪 Soil Parameters")
    N   = st.slider("Nitrogen (N)  kg/ha",  0,  200, 90)
    P   = st.slider("Phosphorus (P) kg/ha", 0,  100, 42)
    K   = st.slider("Potassium (K)  kg/ha", 0,  200, 43)
    pH  = st.slider("Soil pH",              3.5, 9.0, 6.2, step=0.1)
    sm  = st.slider("Soil Moisture (%)",    10,  100, 55)
    st_key = st.selectbox("Soil Type", ["Loamy", "Sandy", "Clay"])
    soil_type_int = {"Loamy": 0, "Sandy": 1, "Clay": 2}[st_key]

    st.markdown("---")
    st.subheader("🌤️ Climate Parameters")
    rain  = st.slider("Rainfall (mm)",      0,   400, 200)
    temp  = st.slider("Temperature (°C)",   5,    45, 27)
    hum   = st.slider("Humidity (%)",       10,  100, 82)
    sun   = st.slider("Sunlight (hrs/day)", 2,    12,  7)

    st.markdown("---")
    st.subheader("📍 Location Metadata")
    alt    = st.slider("Altitude (m)",     0, 2500, 150)
    region = st.selectbox("Region", REGIONS, index=6)
    season = st.selectbox("Season", SEASONS, index=0)
    season_idx = SEASONS.index(season)
    top_k  = st.radio("Top K Crops", [3, 5], index=0)

    st.markdown("---")
    predict_btn = st.button("🔍 Predict Crops", use_container_width=True)
    ai_btn      = st.button("🤖 Get AI Advice", use_container_width=True)

# ─── Main area ────────────────────────────────────────────────────────────────
st.title("🌾 CropAI — Smart Crop Recommendation System")
st.caption("Machine Learning + AI-powered agronomic intelligence for smarter farming")

pipeline, le = load_model()
df           = get_dataset()

tabs = st.tabs(["📊 Predictions", "📈 EDA & Insights", "🤖 AI Recommendations", "📋 About"])

# ── TAB 1 — Predictions ───────────────────────────────────────────────────────
with tabs[0]:
    if predict_btn or st.session_state.get("predictions"):

        predictions = predict_crops(
            pipeline, le,
            N=N, P=P, K=K, pH=pH,
            rainfall=rain, temperature=temp, humidity=hum,
            soil_moisture=sm, soil_type=soil_type_int,
            sunlight_hrs=sun, altitude_m=alt,
            season=season_idx, top_k=top_k,
        )
        st.session_state["predictions"] = predictions
        st.session_state["input"] = dict(
            N=N, P=P, K=K, pH=pH, rain=rain, temp=temp,
            hum=hum, region=region, season=season
        )

        st.subheader("🏆 Top Recommended Crops")
        cols = st.columns(len(predictions))
        medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"]
        for col, pred, medal in zip(cols, predictions, medals):
            with col:
                st.metric(
                    label=f"{medal} Rank #{pred['rank']}",
                    value=pred["crop"],
                    delta=f"{pred['confidence']*100:.1f}% confidence",
                )

        # Confidence chart
        st.subheader("📊 Confidence Scores")
        fig = go.Figure(go.Bar(
            x=[p["crop"] for p in predictions],
            y=[p["confidence"] * 100 for p in predictions],
            marker=dict(
                color=[p["confidence"] * 100 for p in predictions],
                colorscale="Greens", showscale=True,
                colorbar=dict(title="Confidence %")
            ),
            text=[f"{p['confidence']*100:.1f}%" for p in predictions],
            textposition="outside",
        ))
        fig.update_layout(
            title="Crop Suitability Confidence",
            xaxis_title="Crop", yaxis_title="Confidence (%)",
            yaxis_range=[0, 110], template="plotly_white",
            height=400,
        )
        st.plotly_chart(fig, use_container_width=True)

        # Input summary
        with st.expander("📋 Input Summary", expanded=False):
            c1, c2, c3 = st.columns(3)
            with c1:
                st.markdown("**Soil**")
                st.write(f"N={N} | P={P} | K={K}")
                st.write(f"pH={pH} | Moisture={sm}% | Type={st_key}")
            with c2:
                st.markdown("**Climate**")
                st.write(f"Rain={rain}mm | Temp={temp}°C")
                st.write(f"Humidity={hum}% | Sun={sun}hrs")
            with c3:
                st.markdown("**Location**")
                st.write(f"Region={region} | Season={season}")
                st.write(f"Altitude={alt}m")
    else:
        st.info("👈 Adjust the parameters in the sidebar and click **Predict Crops**.")

        # Show sample radar chart to demonstrate app
        categories = ["N", "P", "K", "pH×10", "Rainfall÷10", "Temp", "Humidity"]
        values     = [90, 42, 43, 62, 20, 27, 82]
        fig = go.Figure(go.Scatterpolar(
            r=values + [values[0]], theta=categories + [categories[0]],
            fill="toself", fillcolor="rgba(46,125,50,0.25)",
            line=dict(color="#2e7d32", width=2),
            name="Current Conditions"
        ))
        fig.update_layout(
            polar=dict(radialaxis=dict(visible=True)),
            title="Soil & Climate Radar (Demo)",
            template="plotly_white", height=400,
        )
        st.plotly_chart(fig, use_container_width=True)


# ── TAB 2 — EDA ───────────────────────────────────────────────────────────────
with tabs[1]:
    st.subheader("📈 Dataset Insights")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Samples",   f"{len(df):,}")
    c2.metric("Crop Types",      df["crop"].nunique())
    c3.metric("Avg Temperature", f"{df['temperature_c'].mean():.1f}°C")
    c4.metric("Avg Rainfall",    f"{df['rainfall_mm'].mean():.0f}mm")

    st.markdown("---")

    # Class distribution
    st.subheader("🌱 Crop Distribution")
    crop_dist = df["crop"].value_counts().reset_index()
    crop_dist.columns = ["Crop", "Count"]
    fig = px.bar(crop_dist, x="Crop", y="Count",
                 color="Count", color_continuous_scale="Greens",
                 title="Sample Count per Crop Type",
                 template="plotly_white")
    st.plotly_chart(fig, use_container_width=True)

    c1, c2 = st.columns(2)

    with c1:
        st.subheader("🌡️ Temperature by Season")
        fig = px.box(df, x="season_name", y="temperature_c",
                     color="season_name",
                     category_orders={"season_name": SEASONS},
                     template="plotly_white",
                     title="Temperature Distribution Across Seasons")
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.subheader("🌧️ Rainfall by Season")
        fig = px.box(df, x="season_name", y="rainfall_mm",
                     color="season_name",
                     category_orders={"season_name": SEASONS},
                     template="plotly_white",
                     title="Rainfall Distribution Across Seasons",
                     color_discrete_sequence=px.colors.qualitative.Pastel)
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    # Correlation heatmap
    st.subheader("🔥 Feature Correlation Heatmap")
    corr = df[FEATURE_COLS].corr()
    fig  = px.imshow(corr, text_auto=".2f", aspect="auto",
                     color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
                     title="Soil & Climate Feature Correlations")
    fig.update_layout(height=500, template="plotly_white")
    st.plotly_chart(fig, use_container_width=True)

    # Scatter explorer
    st.subheader("🔍 Feature Explorer")
    fc1, fc2 = st.columns(2)
    x_feat = fc1.selectbox("X Axis", FEATURE_COLS, index=6)
    y_feat = fc2.selectbox("Y Axis", FEATURE_COLS, index=7)
    sample = df.sample(min(400, len(df)), random_state=42)
    fig = px.scatter(sample, x=x_feat, y=y_feat, color="crop",
                     template="plotly_white",
                     title=f"{x_feat} vs {y_feat} by Crop Type",
                     opacity=0.7)
    st.plotly_chart(fig, use_container_width=True)


# ── TAB 3 — AI Recommendations ───────────────────────────────────────────────
with tabs[2]:
    st.subheader("🤖 AI-Powered Crop Advisory  (Claude API)")

    predictions = st.session_state.get("predictions")
    inp         = st.session_state.get("input", {})

    if not predictions:
        st.warning("Run a prediction first (Tab 1) to unlock AI advisory.")
    else:
        crop_list = [p["crop"] for p in predictions]
        st.markdown("**Predicted crops being analysed:**  " +
                    "  ".join(f'<span class="crop-badge">{c}</span>' for c in crop_list),
                    unsafe_allow_html=True)

        if ai_btn or "ai_response" in st.session_state:
            if ai_btn:
                with st.spinner("Consulting Claude AI …"):
                    ai_text = get_ai_recommendation(
                        N=inp.get("N", N), P=inp.get("P", P),
                        K=inp.get("K", K), pH=inp.get("pH", pH),
                        rainfall=inp.get("rain", rain),
                        temperature=inp.get("temp", temp),
                        humidity=inp.get("hum", hum),
                        region=inp.get("region", region),
                        season=inp.get("season", season),
                        crop_list=crop_list,
                    )
                st.session_state["ai_response"] = ai_text

            ai_text = st.session_state["ai_response"]
            st.markdown(f'<div class="ai-box">{ai_text}</div>', unsafe_allow_html=True)
            st.download_button("⬇️ Download AI Report",
                               data=ai_text,
                               file_name="crop_ai_report.txt",
                               mime="text/plain")
        else:
            st.info("Click **🤖 Get AI Advice** in the sidebar to get detailed recommendations.")

            st.markdown("""
            **The AI report will include:**
            - 💰 Profitability ranking & estimated yield/price
            - 📈 Market demand & price trend for each crop
            - ⚠️ Risk factors (pests, drought, market volatility)
            - 🌱 Recommended farming practices
            - 💎 Alternative high-value crop suggestions
            """)


# ── TAB 4 — About ─────────────────────────────────────────────────────────────
with tabs[3]:
    st.subheader("📋 About This System")

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("""
        ### 🌾 CropAI Pipeline
        An end-to-end agricultural intelligence platform combining:
        - **Machine Learning** for objective crop suitability scoring
        - **Claude AI** for agronomic, economic & risk advisory
        - **Interactive EDA** for data-driven insights

        ### 🔬 Models Used
        | Model | Type |
        |---|---|
        | Random Forest | Ensemble / Tree-based |
        | XGBoost | Gradient Boosting |
        | KNN | Instance-based |
        | SVM | Kernel-based |

        The best model (by weighted F1) is auto-selected and saved.
        """)
    with col2:
        st.markdown("""
        ### 📥 Features Used for Prediction
        | Feature | Description |
        |---|---|
        | N, P, K | Soil nutrient levels (kg/ha) |
        | pH | Soil acidity / alkalinity |
        | Soil Moisture | Volumetric water content % |
        | Soil Type | Loamy / Sandy / Clay |
        | Rainfall | Average monthly rainfall (mm) |
        | Temperature | Mean temperature (°C) |
        | Humidity | Relative humidity (%) |
        | Sunlight | Daily sunlight hours |
        | Altitude | Metres above sea level |
        | Season | Kharif / Rabi / Zaid / etc. |

        ### 🔐 API Key
        Set your key as an environment variable:
        ```
        export ANTHROPIC_API_KEY="sk-ant-..."
        ```
        """)

    st.markdown("---")
    st.caption("Built with ❤️ using Python · scikit-learn · XGBoost · Claude API · Streamlit · Plotly")
