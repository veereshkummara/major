# 🌾 CropAI — Intelligent Crop Recommendation System

An end-to-end agricultural intelligence pipeline that combines **Machine Learning** and **Claude AI** to recommend the most profitable and suitable crops for any given soil and climate conditions.

---

## 📁 Project Structure

```
crop-ai/
├── crop_prediction.py     ← Full ML pipeline (train, predict, AI)
├── streamlit_app.py       ← Interactive web dashboard
├── requirements.txt       ← All Python dependencies
├── README.md              ← This file
├── best_model.joblib      ← Saved best model (auto-generated)
├── .env.example           ← Environment variable template
└── plots/                 ← Auto-generated EDA & model charts
    ├── 01_feature_distributions.png
    ├── 02_correlation_heatmap.png
    ├── 03_class_distribution.png
    ├── 04_seasonal_patterns.png
    ├── 05_model_comparison.png
    ├── fi_randomforest.png
    ├── fi_xgboost.png
    └── cm_*.png
```

---

## ⚙️ Setup & Installation

### 1. Clone / Download

```bash
git clone <repo-url>
cd crop-ai
```

### 2. Create a Virtual Environment (recommended)

```bash
python -m venv venv
source venv/bin/activate        # Linux / macOS
venv\Scripts\activate           # Windows
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Set API Key

The Claude AI recommendation feature requires an Anthropic API key.

**Option A — Environment variable (recommended):**
```bash
export ANTHROPIC_API_KEY="sk-ant-api03-..."        # Linux / macOS
set  ANTHROPIC_API_KEY=sk-ant-api03-...            # Windows CMD
$env:ANTHROPIC_API_KEY="sk-ant-api03-..."          # PowerShell
```

**Option B — `.env` file:**
```bash
cp .env.example .env
# Edit .env and paste your key
```

---

## 🚀 Running the Pipeline

### Full Pipeline (CLI)

```bash
# Use synthetic data (auto-generated)
python crop_prediction.py

# Use your own CSV dataset
python crop_prediction.py path/to/your/dataset.csv
```

The pipeline will:
1. ✅ Generate / load dataset
2. ✅ Run EDA and save plots to `plots/`
3. ✅ Train 4 ML models and compare them
4. ✅ Save the best model as `best_model.joblib`
5. ✅ Predict top 3 crops for a sample input
6. ✅ Get AI-powered advice from Claude API

---

### Interactive Dashboard (Streamlit)

```bash
streamlit run streamlit_app.py
```

Opens at **http://localhost:8501** with:
- Sidebar sliders for all soil & climate inputs
- Top-K crop predictions with confidence bars
- Interactive EDA charts (correlation heatmap, seasonal patterns, scatter explorer)
- AI recommendation panel with download option

---

## 🧪 Sample Input / Output

### Input

```python
{
    "N": 90,          # Nitrogen (kg/ha)
    "P": 42,          # Phosphorus (kg/ha)
    "K": 43,          # Potassium (kg/ha)
    "pH": 6.2,        # Soil pH
    "rainfall": 200,  # mm/month
    "temperature": 27,# °C
    "humidity": 82,   # %
    "region": "Coastal",
    "season": "Kharif"
}
```

### ML Prediction Output

```
======================================================
  SECTION 4 · CROP PREDICTION RESULTS
======================================================
  #1  Rice         [████████████████████████████████░░░░░░░]  83.4%
  #2  Sugarcane    [██████████████░░░░░░░░░░░░░░░░░░░░░░░░░]  34.7%
  #3  Banana       [████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░]  21.2%
```

### AI Recommendation Output (Claude)

```
╔══════════════════════════════════════════════════════════╗
║          🌾  AI CROP RECOMMENDATION  (Claude)            ║
╚══════════════════════════════════════════════════════════╝

  1. PROFITABILITY RANKING
  ━━━━━━━━━━━━━━━━━━━━━━━
  • Rice: ₹18,000–22,000/acre (high demand, stable price)
  • Banana: ₹25,000–35,000/acre (premium coastal variety)
  • Sugarcane: ₹12,000–16,000/acre (assured purchase policy)

  2. MARKET DEMAND & PRICE TRENDS
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  • Rice:      ↔ Stable  — domestic staple with MSP support
  • Banana:    ↑ Rising  — export demand, tissue-culture adoption
  • Sugarcane: ↔ Stable  — controlled by FRP, predictable income

  [... continues with risk assessment, practices, alternatives ...]
```

---

## 📊 ML Models Compared

| Model | Accuracy | Weighted F1 |
|---|---|---|
| Random Forest | ~96% | ~0.96 |
| XGBoost | ~97% | ~0.97 |
| KNN | ~91% | ~0.91 |
| SVM (RBF) | ~94% | ~0.94 |

> Scores will vary slightly due to random sampling. Best model is auto-selected and saved.

---

## 🌱 Crops Supported (Synthetic Data)

| Crop | Season | Soil | Climate |
|---|---|---|---|
| Rice | Kharif | Loamy/Clay | Hot & humid |
| Wheat | Rabi | Loamy/Sandy | Cool & dry |
| Maize | Kharif | Loamy/Sandy | Warm |
| Cotton | Kharif | Sandy/Loamy | Hot & dry |
| Sugarcane | Annual | Loamy/Clay | Hot & wet |
| Millet | Kharif | Sandy/Loamy | Arid |
| Soybean | Kharif | Loamy/Clay | Warm |
| Chickpea | Rabi | Sandy/Loamy | Cool & dry |
| Banana | Perennial | Loamy/Clay | Tropical |
| Coffee | Perennial | Loamy/Clay | Mild hills |
| Tea | Perennial | Loamy/Clay | Cool hills |
| Tomato | Rabi/Zaid | Loamy/Sandy | Warm |

---

## 📄 Using Your Own Dataset

Your CSV should have these columns (or a subset):

```
N, P, K, pH, soil_moisture, soil_type, rainfall_mm,
temperature_c, humidity_pct, sunlight_hrs, altitude_m,
season, region, crop
```

Where `soil_type` is 0=loamy, 1=sandy, 2=clay and `season` / `region`
are integer-encoded.  Pass the path as the first CLI argument:

```bash
python crop_prediction.py data/my_farm_data.csv
```

---

## 🔐 Environment Variables

| Variable | Description | Required |
|---|---|---|
| `ANTHROPIC_API_KEY` | Claude API key from console.anthropic.com | For AI advisory |

Create a `.env` file:
```env
ANTHROPIC_API_KEY=sk-ant-api03-your-key-here
```

---

## 📦 Key Dependencies

| Package | Purpose |
|---|---|
| `pandas`, `numpy` | Data handling |
| `scikit-learn` | ML models, preprocessing, metrics |
| `xgboost` | Gradient boosting classifier |
| `matplotlib`, `seaborn` | Static visualisation |
| `plotly` | Interactive charts |
| `joblib` | Model serialisation |
| `anthropic` | Claude AI API |
| `streamlit` | Web dashboard |
| `python-dotenv` | `.env` file loader |

---

## 🙋 FAQ

**Q: The AI section is skipped — why?**  
A: Set your `ANTHROPIC_API_KEY` environment variable (see Setup).

**Q: XGBoost is missing?**  
A: Run `pip install xgboost`. The pipeline degrades gracefully without it.

**Q: Can I add more crops?**  
A: Yes — add entries to the `CROP_PROFILES` dict in `crop_prediction.py` with realistic agronomic ranges.

---

*Built with Python · scikit-learn · XGBoost · Anthropic Claude · Streamlit · Plotly*
