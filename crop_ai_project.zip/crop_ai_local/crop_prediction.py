"""
=============================================================================
  CROP PREDICTION PIPELINE — Agricultural AI System
  Author  : Agricultural Data Science Pipeline
  Purpose : End-to-end ML pipeline for crop recommendation with AI insights
=============================================================================
"""

import os
import sys
import warnings
import json
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")          # non-interactive backend for script mode
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import joblib

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    classification_report, confusion_matrix,
    accuracy_score, f1_score
)
from sklearn.pipeline import Pipeline

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    print("[WARN] xgboost not installed. Skipping XGBoost model.")

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False
    print("[WARN] anthropic not installed. AI recommendations will be skipped.")

# ─────────────────────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────
CONFIG = {
    "random_seed":    42,
    "test_size":      0.20,
    "n_samples":      1200,
    "model_save_path": "best_model.joblib",
    "plots_dir":      "plots",
    "api_key_env":    "ANTHROPIC_API_KEY",      # env-var name, never hardcoded
    "claude_model":   "claude-sonnet-4-20250514",
    "top_k_crops":    3,
}

np.random.seed(CONFIG["random_seed"])
os.makedirs(CONFIG["plots_dir"], exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 · DATA GENERATION / LOADING
# ─────────────────────────────────────────────────────────────────────────────

# Agronomic reference table — realistic ranges per crop
CROP_PROFILES = {
    "Rice":      dict(N=(80,120), P=(40,60),  K=(40,60),  pH=(5.5,6.5), rain=(150,250), temp=(22,32), hum=(70,90), sun=(5,8),  alt=(0,300),  soil=["loamy","clay"]),
    "Wheat":     dict(N=(60,100), P=(30,50),  K=(30,50),  pH=(6.0,7.5), rain=(50,100),  temp=(12,22), hum=(50,70), sun=(6,9),  alt=(200,800), soil=["loamy","sandy"]),
    "Maize":     dict(N=(80,120), P=(40,70),  K=(40,70),  pH=(5.8,7.0), rain=(80,140),  temp=(18,28), hum=(55,75), sun=(6,9),  alt=(0,500),   soil=["loamy","sandy"]),
    "Cotton":    dict(N=(50,80),  P=(20,40),  K=(20,40),  pH=(6.0,7.5), rain=(60,120),  temp=(20,35), hum=(40,70), sun=(7,10), alt=(0,600),   soil=["sandy","loamy"]),
    "Sugarcane": dict(N=(80,120), P=(30,50),  K=(100,150),pH=(6.0,7.5), rain=(120,200), temp=(24,35), hum=(65,85), sun=(6,9),  alt=(0,400),   soil=["loamy","clay"]),
    "Millet":    dict(N=(40,80),  P=(20,40),  K=(20,40),  pH=(6.0,7.5), rain=(30,80),   temp=(25,38), hum=(30,60), sun=(7,10), alt=(200,700), soil=["sandy","loamy"]),
    "Soybean":   dict(N=(20,50),  P=(40,70),  K=(30,60),  pH=(6.0,7.0), rain=(80,140),  temp=(20,30), hum=(60,80), sun=(6,9),  alt=(0,500),   soil=["loamy","clay"]),
    "Chickpea":  dict(N=(20,50),  P=(40,70),  K=(20,40),  pH=(6.0,8.0), rain=(30,80),   temp=(15,25), hum=(30,60), sun=(6,9),  alt=(400,1200),soil=["sandy","loamy"]),
    "Banana":    dict(N=(100,150),P=(40,70),  K=(150,200),pH=(5.5,7.0), rain=(120,200), temp=(22,35), hum=(70,90), sun=(5,8),  alt=(0,400),   soil=["loamy","clay"]),
    "Coffee":    dict(N=(60,100), P=(30,50),  K=(60,100), pH=(5.5,6.5), rain=(120,200), temp=(18,26), hum=(70,90), sun=(4,7),  alt=(500,2000),soil=["loamy","clay"]),
    "Tea":       dict(N=(50,80),  P=(20,40),  K=(30,60),  pH=(4.5,5.5), rain=(150,300), temp=(15,25), hum=(75,95), sun=(4,7),  alt=(600,2200),soil=["loamy","clay"]),
    "Tomato":    dict(N=(80,120), P=(50,80),  K=(60,100), pH=(6.0,7.0), rain=(60,120),  temp=(18,28), hum=(50,75), sun=(7,10), alt=(0,1200),  soil=["loamy","sandy"]),
}

SEASONS    = ["Kharif", "Rabi", "Zaid", "Summer", "Winter"]
REGIONS    = ["North", "South", "East", "West", "Central", "Deccan", "Coastal"]
SOIL_TYPES = ["loamy", "sandy", "clay"]
SOIL_MAP   = {"loamy": 0, "sandy": 1, "clay": 2}

def generate_synthetic_dataset(n_samples: int = 1200) -> pd.DataFrame:
    """
    Generate a realistic synthetic agronomic dataset.

    For every crop we sample features from its agronomic comfort zone,
    adding calibrated Gaussian noise so distributions overlap naturally —
    just as they would in real field data.

    Parameters
    ----------
    n_samples : int
        Total number of rows to produce.

    Returns
    -------
    pd.DataFrame
        DataFrame with 15 feature columns + 'crop' target label.
    """
    crops  = list(CROP_PROFILES.keys())
    n_crop = n_samples // len(crops)
    rows   = []

    for crop in crops:
        p = CROP_PROFILES[crop]
        n = n_crop + (n_samples % len(crops) if crop == crops[-1] else 0)

        def rnd(lo, hi, sigma_frac=0.08):
            base = np.random.uniform(lo, hi, n)
            noise = np.random.normal(0, (hi - lo) * sigma_frac, n)
            return np.clip(base + noise, lo * 0.8, hi * 1.2)

        soil_choices = np.random.choice(p["soil"], n)
        season_idx   = np.random.choice(range(len(SEASONS)), n)
        region_idx   = np.random.choice(range(len(REGIONS)), n)

        chunk = pd.DataFrame({
            "N":            rnd(*p["N"]),
            "P":            rnd(*p["P"]),
            "K":            rnd(*p["K"]),
            "pH":           np.clip(rnd(*p["pH"], sigma_frac=0.03), 3.5, 9.0),
            "soil_moisture": np.random.uniform(20, 80, n),
            "soil_type":    [SOIL_MAP[s] for s in soil_choices],
            "rainfall_mm":  rnd(*p["rain"]),
            "temperature_c": rnd(*p["temp"]),
            "humidity_pct": rnd(*p["hum"]),
            "sunlight_hrs": rnd(*p["sun"]),
            "altitude_m":   rnd(*p["alt"]),
            "season":       season_idx,
            "region":       region_idx,
            "season_name":  [SEASONS[i] for i in season_idx],
            "region_name":  [REGIONS[i] for i in region_idx],
            "soil_name":    soil_choices,
            "crop":         crop,
        })
        rows.append(chunk)

    df = pd.concat(rows, ignore_index=True).sample(frac=1, random_state=CONFIG["random_seed"])
    df = df.reset_index(drop=True)
    print(f"  ✔  Synthetic dataset created  →  {len(df):,} rows × {df.shape[1]} columns")
    return df


def load_dataset(csv_path: str | None = None) -> pd.DataFrame:
    """
    Load a CSV dataset or fall back to synthetic generation.

    Parameters
    ----------
    csv_path : str or None
        Path to an existing CSV file.  Pass None to auto-generate.

    Returns
    -------
    pd.DataFrame
    """
    if csv_path and os.path.exists(csv_path):
        df = pd.read_csv(csv_path)
        print(f"  ✔  Loaded CSV  →  {df.shape}")
        return df
    print("  ℹ  No CSV found — generating synthetic dataset …")
    return generate_synthetic_dataset(CONFIG["n_samples"])


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 · EXPLORATORY DATA ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

FEATURE_COLS = [
    "N", "P", "K", "pH", "soil_moisture",
    "rainfall_mm", "temperature_c", "humidity_pct",
    "sunlight_hrs", "altitude_m",
]

def run_eda(df: pd.DataFrame) -> None:
    """
    Produce and save all EDA visualisations.

    Generates:
    - Feature distribution grid
    - Correlation heat-map
    - Crop class distribution bar-chart
    - Seasonal rainfall / temperature box-plots

    Parameters
    ----------
    df : pd.DataFrame
        The full dataset (synthetic or loaded).
    """
    print("\n" + "=" * 60)
    print("  SECTION 2 · EXPLORATORY DATA ANALYSIS")
    print("=" * 60)

    palette = sns.color_palette("viridis", n_colors=12)
    sns.set_theme(style="whitegrid", font_scale=0.9)

    # 2-A  Feature distributions ──────────────────────────────────────────────
    fig, axes = plt.subplots(2, 5, figsize=(20, 8))
    fig.suptitle("Feature Distributions", fontsize=16, fontweight="bold", y=1.01)
    for ax, col in zip(axes.flat, FEATURE_COLS):
        sns.histplot(df[col], kde=True, ax=ax, color="#2ECC71", edgecolor="white")
        ax.set_title(col, fontsize=10)
        ax.set_xlabel("")
    plt.tight_layout()
    path = os.path.join(CONFIG["plots_dir"], "01_feature_distributions.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔  Saved → {path}")

    # 2-B  Correlation heat-map ───────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(11, 9))
    corr = df[FEATURE_COLS].corr()
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(
        corr, mask=mask, annot=True, fmt=".2f",
        cmap="coolwarm", center=0, linewidths=0.5,
        ax=ax, annot_kws={"size": 8}
    )
    ax.set_title("Soil & Climate Feature Correlation", fontsize=14, fontweight="bold")
    plt.tight_layout()
    path = os.path.join(CONFIG["plots_dir"], "02_correlation_heatmap.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔  Saved → {path}")

    # 2-C  Class distribution ─────────────────────────────────────────────────
    crop_counts = df["crop"].value_counts().reset_index()
    crop_counts.columns = ["crop", "count"]
    fig, ax = plt.subplots(figsize=(12, 5))
    bars = ax.bar(
        crop_counts["crop"], crop_counts["count"],
        color=sns.color_palette("tab20", len(crop_counts)),
        edgecolor="white", linewidth=0.8
    )
    ax.bar_label(bars, padding=3, fontsize=8)
    ax.set_title("Crop Class Distribution", fontsize=14, fontweight="bold")
    ax.set_xlabel("Crop Type")
    ax.set_ylabel("Sample Count")
    ax.tick_params(axis="x", rotation=35)
    plt.tight_layout()
    path = os.path.join(CONFIG["plots_dir"], "03_class_distribution.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔  Saved → {path}")

    # 2-D  Seasonal patterns ──────────────────────────────────────────────────
    if "season_name" in df.columns:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
        sns.boxplot(data=df, x="season_name", y="rainfall_mm",
                    palette="Blues", ax=ax1, order=SEASONS)
        ax1.set_title("Rainfall by Season", fontsize=12, fontweight="bold")
        ax1.set_xlabel("Season")
        ax1.set_ylabel("Rainfall (mm)")

        sns.boxplot(data=df, x="season_name", y="temperature_c",
                    palette="Reds",  ax=ax2, order=SEASONS)
        ax2.set_title("Temperature by Season", fontsize=12, fontweight="bold")
        ax2.set_xlabel("Season")
        ax2.set_ylabel("Temperature (°C)")

        plt.tight_layout()
        path = os.path.join(CONFIG["plots_dir"], "04_seasonal_patterns.png")
        plt.savefig(path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"  ✔  Saved → {path}")

    # 2-E  Quick numeric summary
    print("\n  ── Numeric Summary ──")
    print(df[FEATURE_COLS].describe().round(2).to_string())
    print(f"\n  Crop class counts:\n{df['crop'].value_counts().to_string()}")


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 · ML MODEL TRAINING & COMPARISON
# ─────────────────────────────────────────────────────────────────────────────

ML_FEATURES = [
    "N", "P", "K", "pH", "soil_moisture", "soil_type",
    "rainfall_mm", "temperature_c", "humidity_pct",
    "sunlight_hrs", "altitude_m", "season",
]

def prepare_features(df: pd.DataFrame):
    """
    Extract ML feature matrix X and encoded target y.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    X : np.ndarray
    y : np.ndarray  (integer-encoded)
    le : LabelEncoder fitted on crop names
    """
    X = df[ML_FEATURES].values.astype(float)
    le = LabelEncoder()
    y  = le.fit_transform(df["crop"])
    return X, y, le


def build_models() -> dict:
    """
    Return a dict of sklearn-compatible model pipelines to benchmark.

    Each pipeline wraps a StandardScaler + classifier so that
    distance-based models (KNN, SVM) benefit from normalisation
    while tree-based models are unaffected.

    Returns
    -------
    dict  {model_name: Pipeline}
    """
    models = {
        "RandomForest": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", RandomForestClassifier(
                n_estimators=200, max_depth=None,
                min_samples_leaf=2, n_jobs=-1,
                random_state=CONFIG["random_seed"]
            ))
        ]),
        "KNN": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", KNeighborsClassifier(n_neighbors=7, metric="minkowski"))
        ]),
        "SVM": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", SVC(kernel="rbf", C=10, gamma="scale",
                        probability=True, random_state=CONFIG["random_seed"]))
        ]),
    }
    if XGBOOST_AVAILABLE:
        models["XGBoost"] = Pipeline([
            ("scaler", StandardScaler()),
            ("clf", XGBClassifier(
                n_estimators=200, max_depth=6,
                learning_rate=0.1, use_label_encoder=False,
                eval_metric="mlogloss",
                random_state=CONFIG["random_seed"],
                verbosity=0
            ))
        ])
    return models


def plot_feature_importance(model_pipeline, feature_names: list, model_name: str) -> None:
    """
    Plot and save feature-importance for tree-based models.

    Parameters
    ----------
    model_pipeline : sklearn Pipeline
    feature_names  : list of str
    model_name     : str  (used for filename)
    """
    clf = model_pipeline.named_steps["clf"]
    if not hasattr(clf, "feature_importances_"):
        return

    importances = clf.feature_importances_
    idx = np.argsort(importances)[::-1]

    fig, ax = plt.subplots(figsize=(10, 5))
    colors = sns.color_palette("viridis", len(feature_names))
    ax.bar(range(len(feature_names)),
           importances[idx], color=[colors[i] for i in range(len(feature_names))])
    ax.set_xticks(range(len(feature_names)))
    ax.set_xticklabels([feature_names[i] for i in idx], rotation=40, ha="right")
    ax.set_title(f"{model_name} — Feature Importances", fontsize=13, fontweight="bold")
    ax.set_ylabel("Importance Score")
    plt.tight_layout()
    path = os.path.join(CONFIG["plots_dir"], f"fi_{model_name.lower()}.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"    ✔  Feature-importance plot → {path}")


def plot_confusion_matrix(y_true, y_pred, labels: list, model_name: str) -> None:
    """
    Save a colour-mapped confusion matrix for a given model.

    Parameters
    ----------
    y_true, y_pred : array-like
    labels         : list of class-name strings
    model_name     : str
    """
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(12, 10))
    sns.heatmap(cm, annot=True, fmt="d", cmap="YlOrRd",
                xticklabels=labels, yticklabels=labels,
                linewidths=0.5, ax=ax)
    ax.set_title(f"{model_name} — Confusion Matrix", fontsize=13, fontweight="bold")
    ax.set_xlabel("Predicted Label")
    ax.set_ylabel("True Label")
    plt.tight_layout()
    path = os.path.join(CONFIG["plots_dir"], f"cm_{model_name.lower()}.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"    ✔  Confusion-matrix plot   → {path}")


def train_and_evaluate(df: pd.DataFrame) -> tuple:
    """
    Train all classifiers, compare metrics, save the best model.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    best_pipeline : fitted sklearn Pipeline
    le            : LabelEncoder for target classes
    results_df    : pd.DataFrame  with per-model accuracy & F1
    """
    print("\n" + "=" * 60)
    print("  SECTION 3 · MODEL TRAINING & EVALUATION")
    print("=" * 60)

    X, y, le = prepare_features(df)
    class_names = list(le.classes_)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=CONFIG["test_size"],
        random_state=CONFIG["random_seed"], stratify=y
    )
    print(f"  Train: {X_train.shape[0]:,}  |  Test: {X_test.shape[0]:,}")

    models   = build_models()
    results  = {}

    for name, pipeline in models.items():
        print(f"\n  ── {name} ──")
        pipeline.fit(X_train, y_train)
        y_pred = pipeline.predict(X_test)
        acc    = accuracy_score(y_test, y_pred)
        f1     = f1_score(y_test, y_pred, average="weighted")
        results[name] = {"accuracy": acc, "f1_weighted": f1, "pipeline": pipeline}

        print(f"    Accuracy : {acc:.4f}   Weighted-F1 : {f1:.4f}")
        print(classification_report(y_test, y_pred, target_names=class_names, digits=3))

        plot_feature_importance(pipeline, ML_FEATURES, name)
        plot_confusion_matrix(y_test, y_pred, class_names, name)

    # ── Model comparison bar-chart ──────────────────────────────────────────
    res_df = pd.DataFrame(
        {k: {"Accuracy": v["accuracy"], "Weighted F1": v["f1_weighted"]}
         for k, v in results.items()}
    ).T

    fig, ax = plt.subplots(figsize=(10, 5))
    x = np.arange(len(res_df))
    w = 0.35
    ax.bar(x - w/2, res_df["Accuracy"],    w, label="Accuracy",    color="#2ECC71")
    ax.bar(x + w/2, res_df["Weighted F1"], w, label="Weighted F1", color="#3498DB")
    ax.set_xticks(x)
    ax.set_xticklabels(res_df.index, fontsize=11)
    ax.set_ylim(0, 1.05)
    ax.set_title("Model Comparison — Accuracy & Weighted F1", fontsize=13, fontweight="bold")
    ax.set_ylabel("Score")
    ax.legend()
    for bar in ax.patches:
        ax.annotate(f"{bar.get_height():.3f}",
                    (bar.get_x() + bar.get_width() / 2, bar.get_height()),
                    ha="center", va="bottom", fontsize=8)
    plt.tight_layout()
    path = os.path.join(CONFIG["plots_dir"], "05_model_comparison.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"\n  ✔  Model comparison chart → {path}")

    # ── Pick best model ──────────────────────────────────────────────────────
    best_name = max(results, key=lambda k: results[k]["f1_weighted"])
    best_pipeline = results[best_name]["pipeline"]
    print(f"\n  🏆  Best model : {best_name}  (F1={results[best_name]['f1_weighted']:.4f})")

    save_path = CONFIG["model_save_path"]
    joblib.dump({"pipeline": best_pipeline, "label_encoder": le}, save_path)
    print(f"  ✔  Model saved → {save_path}")

    return best_pipeline, le, res_df


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 · USER-INPUT PREDICTION
# ─────────────────────────────────────────────────────────────────────────────

def predict_crops(
    pipeline,
    le: LabelEncoder,
    N: float, P: float, K: float, pH: float,
    rainfall: float, temperature: float, humidity: float,
    soil_moisture: float = 50.0,
    soil_type: int = 0,       # 0=loamy, 1=sandy, 2=clay
    sunlight_hrs: float = 7.0,
    altitude_m: float = 200.0,
    season: int = 0,
    top_k: int = 3,
) -> list[dict]:
    """
    Predict the top-k most suitable crops for given conditions.

    Parameters
    ----------
    pipeline   : fitted sklearn Pipeline (scaler + classifier)
    le         : LabelEncoder for crop names
    N,P,K,pH   : soil nutrient values and pH
    rainfall   : average monthly rainfall in mm
    temperature: average temperature in °C
    humidity   : relative humidity in %
    soil_moisture: volumetric soil moisture %
    soil_type  : 0=loamy, 1=sandy, 2=clay
    sunlight_hrs: daily sunlight hours
    altitude_m : metres above sea level
    season     : encoded season index (0–4)
    top_k      : number of crops to return

    Returns
    -------
    list of dict  [{crop, confidence, rank}, …]
    """
    features = np.array([[
        N, P, K, pH, soil_moisture, soil_type,
        rainfall, temperature, humidity,
        sunlight_hrs, altitude_m, season,
    ]], dtype=float)

    proba = pipeline.predict_proba(features)[0]
    top_idx = np.argsort(proba)[::-1][:top_k]

    recommendations = []
    for rank, idx in enumerate(top_idx, start=1):
        recommendations.append({
            "rank":       rank,
            "crop":       le.classes_[idx],
            "confidence": float(proba[idx]),
        })
    return recommendations


def display_predictions(predictions: list[dict]) -> None:
    """Pretty-print the crop predictions to stdout."""
    print("\n" + "=" * 60)
    print("  SECTION 4 · CROP PREDICTION RESULTS")
    print("=" * 60)
    bar_width = 40
    for p in predictions:
        filled = int(p["confidence"] * bar_width)
        bar    = "█" * filled + "░" * (bar_width - filled)
        print(f"  #{p['rank']}  {p['crop']:<12}  [{bar}]  {p['confidence']*100:5.1f}%")


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 · AI-POWERED RECOMMENDATION (Claude API)
# ─────────────────────────────────────────────────────────────────────────────

def build_prompt(
    N: float, P: float, K: float, pH: float,
    rainfall: float, temperature: float, humidity: float,
    region: str, season: str,
    crop_list: list[str],
) -> str:
    """
    Construct the structured prompt sent to Claude.

    Parameters
    ----------
    N, P, K, pH, rainfall, temperature, humidity : floats
    region, season : str
    crop_list : list of predicted crop names

    Returns
    -------
    str  — formatted prompt
    """
    crops_str = ", ".join(crop_list)
    return f"""You are an expert agronomist and agricultural economist advising small and medium farmers.

Given soil conditions:
  - Nitrogen (N): {N} kg/ha
  - Phosphorus (P): {P} kg/ha
  - Potassium (K): {K} kg/ha
  - Soil pH: {pH}
  - Average Rainfall: {rainfall} mm
  - Temperature: {temperature}°C
  - Humidity: {humidity}%
  - Region: {region}
  - Season: {season}

An ML model predicts these top crops are most suitable: {crops_str}

Please provide a comprehensive, structured recommendation covering:

1. **PROFITABILITY RANKING** — Which of these crops is most profitable for small/medium farmers? Include estimated yield per acre and indicative market price range.

2. **MARKET DEMAND & PRICE TRENDS** — Current demand signals and price trajectory for each recommended crop (rising / stable / declining).

3. **RISK ASSESSMENT** — For each crop, list the top 3 risks:
   - Pest / disease vulnerabilities
   - Drought or waterlogging sensitivity
   - Market/price volatility

4. **RECOMMENDED FARMING PRACTICES** — Key agronomic tips for the top crop: sowing time, fertilisation schedule, irrigation strategy, and post-harvest handling.

5. **ALTERNATIVE HIGH-VALUE CROPS** — Suggest 2–3 crops NOT in the ML list that could perform well under these exact conditions and fetch premium prices (e.g., spices, medicinal herbs, specialty vegetables).

Format your answer with clear numbered sections and bullet points. Be practical and specific to the described agro-climatic zone.
"""


def get_ai_recommendation(
    N: float, P: float, K: float, pH: float,
    rainfall: float, temperature: float, humidity: float,
    region: str = "Central",
    season: str  = "Kharif",
    crop_list: list | None = None,
) -> str:
    """
    Call the Claude API and return the AI-generated crop recommendation.

    Reads the API key from the environment variable defined in CONFIG.
    Falls back to a descriptive placeholder if the key is absent or
    the anthropic package is not installed.

    Parameters
    ----------
    See build_prompt() for parameter descriptions.
    crop_list : list of str  (top predicted crops from ML model)

    Returns
    -------
    str  — AI recommendation text
    """
    print("\n" + "=" * 60)
    print("  SECTION 5 · AI-POWERED RECOMMENDATION  (Claude API)")
    print("=" * 60)

    if not ANTHROPIC_AVAILABLE:
        return "  [SKIP]  anthropic package not installed."

    api_key = os.environ.get(CONFIG["api_key_env"])
    if not api_key:
        return (
            f"  [SKIP]  Environment variable '{CONFIG['api_key_env']}' not set.\n"
            "  Set it with:  export ANTHROPIC_API_KEY='sk-ant-...'"
        )

    if not crop_list:
        crop_list = ["Unknown"]

    prompt = build_prompt(N, P, K, pH, rainfall, temperature, humidity,
                          region, season, crop_list)

    print("  Sending request to Claude API …")
    client   = anthropic.Anthropic(api_key=api_key)
    message  = client.messages.create(
        model      = CONFIG["claude_model"],
        max_tokens = 1500,
        messages   = [{"role": "user", "content": prompt}],
    )
    return message.content[0].text


def display_ai_recommendation(text: str) -> None:
    """Print the AI recommendation with a decorative header."""
    print("\n" + "╔" + "═" * 58 + "╗")
    print("║          🌾  AI CROP RECOMMENDATION  (Claude)         ║")
    print("╚" + "═" * 58 + "╝")
    for line in text.splitlines():
        print("  " + line)
    print("─" * 60)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN PIPELINE RUNNER
# ─────────────────────────────────────────────────────────────────────────────

def run_pipeline(
    csv_path: str | None = None,
    sample_input: dict | None = None,
) -> None:
    """
    Orchestrate the full end-to-end pipeline.

    Parameters
    ----------
    csv_path     : optional path to a real CSV dataset
    sample_input : dict with user input fields for prediction demo.
                   Defaults to a sensible demo case if None.
    """
    print("\n" + "█" * 60)
    print("  🌾  CROP PREDICTION PIPELINE  —  Agricultural AI System")
    print("█" * 60)

    # ── 1. Load data ──────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  SECTION 1 · DATA LOADING")
    print("=" * 60)
    df = load_dataset(csv_path)

    # ── 2. EDA ────────────────────────────────────────────────────────────────
    run_eda(df)

    # ── 3. Train models ───────────────────────────────────────────────────────
    best_pipeline, le, results_df = train_and_evaluate(df)
    print("\n  Model leaderboard:")
    print(results_df.round(4).to_string())

    # ── 4. User-input prediction ──────────────────────────────────────────────
    if sample_input is None:
        sample_input = {
            "N": 90, "P": 42, "K": 43, "pH": 6.2,
            "rainfall": 200, "temperature": 27,
            "humidity": 82,
            "soil_moisture": 55, "soil_type": 0,
            "sunlight_hrs": 6.5, "altitude_m": 150,
            "season": 0,
            "region_name": "Coastal", "season_name": "Kharif",
        }

    print("\n" + "=" * 60)
    print("  SECTION 4 · USER INPUT")
    print("=" * 60)
    for k, v in sample_input.items():
        print(f"    {k:<20} : {v}")

    predictions = predict_crops(
        best_pipeline, le,
        N=sample_input["N"],
        P=sample_input["P"],
        K=sample_input["K"],
        pH=sample_input["pH"],
        rainfall=sample_input["rainfall"],
        temperature=sample_input["temperature"],
        humidity=sample_input["humidity"],
        soil_moisture=sample_input.get("soil_moisture", 50),
        soil_type=sample_input.get("soil_type", 0),
        sunlight_hrs=sample_input.get("sunlight_hrs", 7),
        altitude_m=sample_input.get("altitude_m", 200),
        season=sample_input.get("season", 0),
        top_k=CONFIG["top_k_crops"],
    )
    display_predictions(predictions)

    # ── 5. AI recommendation ──────────────────────────────────────────────────
    crop_list = [p["crop"] for p in predictions]
    ai_text   = get_ai_recommendation(
        N=sample_input["N"],
        P=sample_input["P"],
        K=sample_input["K"],
        pH=sample_input["pH"],
        rainfall=sample_input["rainfall"],
        temperature=sample_input["temperature"],
        humidity=sample_input["humidity"],
        region=sample_input.get("region_name", "Central"),
        season=sample_input.get("season_name", "Kharif"),
        crop_list=crop_list,
    )
    display_ai_recommendation(ai_text)

    print("\n" + "█" * 60)
    print("  ✅  Pipeline complete.  Check the 'plots/' directory for all charts.")
    print("█" * 60 + "\n")


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    csv_arg = sys.argv[1] if len(sys.argv) > 1 else None
    run_pipeline(csv_path=csv_arg)
